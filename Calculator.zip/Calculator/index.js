let input = document.getElementById("txt");
let buttons = document.querySelectorAll("button");

for (value of buttons) {
    value.addEventListener("click", (e) => {
        buttonText = e.target.innerText;

        if (buttonText === "X") {
            buttonText = "*";
            input.value += buttonText;
        } else if (buttonText === "C") {
            input.value = "";
        } else if (buttonText === "=") {
            input.value = eval(input.value);
        } else if (buttonText === "%") {
            input.value += "/100*";
        } else {
            input.value += buttonText;
        }
    });
}